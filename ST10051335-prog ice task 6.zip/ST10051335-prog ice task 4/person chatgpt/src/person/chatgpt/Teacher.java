
package person.chatgpt;

// Teacher class extending Person
public class Teacher extends Person {
    private String subject;

    // Constructor for Teacher class
    public Teacher(String name, int age, String email, String subject) {
        super(name, age, email);  // Call the constructor of Person
        this.subject = subject;
    }

    // Method to display teacher information
    public void displayTeacherInfo() {
        displayInfo();  // Call the displayInfo() from Person
        System.out.println("Subject: " + subject);
    }
}


