
package person.chatgpt;


public class Main {
    public static void main(String[] args) {
        // Create a Student instance
        Student student = new Student("Alice", 20, "alice@example.com", "S1234");
        // Create a Teacher instance
        Teacher teacher = new Teacher("Mr. Smith", 45, "smith@example.com", "Mathematics");

        // Display information for both student and teacher
        System.out.println("Student Information:");
        student.displayStudentInfo();

        System.out.println("\nTeacher Information:");
        teacher.displayTeacherInfo();
    }
}
