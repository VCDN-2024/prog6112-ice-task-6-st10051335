
package person.chatgpt;


// Student class extending Person
public class Student extends Person {
    private String studentID;

    // Constructor for Student class
    public Student(String name, int age, String email, String studentID) {
        super(name, age, email);  // Call the constructor of Person
        this.studentID = studentID;
    }

    // Method to display student information
    public void displayStudentInfo() {
        displayInfo();  // Call the displayInfo() from Person
        System.out.println("Student ID: " + studentID);
    }
}

